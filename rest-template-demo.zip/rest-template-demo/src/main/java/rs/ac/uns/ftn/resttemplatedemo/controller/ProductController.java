package rs.ac.uns.ftn.resttemplatedemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import rs.ac.uns.ftn.resttemplatedemo.dto.PriceChangeDto;
import rs.ac.uns.ftn.resttemplatedemo.dto.ProductDto;
import rs.ac.uns.ftn.resttemplatedemo.service.HttpClientService;

import java.util.List;

@RestController
@RequestMapping("/product")
public class ProductController {

    private final HttpClientService client;

    @Autowired
    public ProductController(HttpClientService client) {
        this.client = client;
    }

    @RequestMapping(value = "", method = RequestMethod.GET)
    public ResponseEntity<?> getProducts() {
        ResponseEntity<?> result;
        try {
            List<ProductDto> dtoList = client.getProducts();
            result = dtoList == null ?
                    ResponseEntity.badRequest().body("Bad request!") : new ResponseEntity<>(dtoList, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            result = ResponseEntity.badRequest().body("Bad request!");
        }
        return result;
    }

    @RequestMapping(value = "", method = RequestMethod.POST)
    public ResponseEntity<?> addProduct(@RequestBody ProductDto dto) {
        ResponseEntity<?> result;
        try {
            boolean action = client.addProduct(dto);
            result = action ? new ResponseEntity<>(HttpStatus.OK) : ResponseEntity.badRequest().body("Bad request!");
        } catch (Exception e) {
            e.printStackTrace();
            result = ResponseEntity.badRequest().body("Bad request!");
        }
        return result;
    }

    @RequestMapping(value = "", method = RequestMethod.PUT)
    public ResponseEntity<?> modifyProduct(@RequestBody PriceChangeDto dto) {
        ResponseEntity<?> result;
        try {
            ProductDto resultDto = client.modifyProduct(dto);
            result = resultDto == null ?
                    ResponseEntity.badRequest().body("Bad request!") : new ResponseEntity<>(resultDto, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            result = ResponseEntity.badRequest().body("Bad request!");
        }
        return result;
    }
}
