package rs.ac.uns.ftn.resttemplatedemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import rs.ac.uns.ftn.resttemplatedemo.dto.PriceChangeDto;
import rs.ac.uns.ftn.resttemplatedemo.dto.ProductDto;

import java.util.Arrays;
import java.util.List;

@Service
public class HttpClientService {

    private static final String API_URL = "http://localhost:51963/";
    private final RestTemplate restTemplate;

    @Autowired
    public HttpClientService() {
        this.restTemplate = new RestTemplate();
    }

    public List<ProductDto> getProducts() {
        List<ProductDto> result = null;
        try {
            ProductDto[] response = restTemplate.getForObject(API_URL + "/api/product", ProductDto[].class);
            if (response != null) {
                result = Arrays.asList(response);
                result.forEach(product -> System.out.println(product.toString()));
            }
        } catch (Exception e) {
            e.printStackTrace();
            result = null;
        }
        return result;
    }

    public boolean addProduct(ProductDto dto) {
        boolean result;
        try {
            ResponseEntity<?> response = restTemplate.exchange(API_URL + "/api/product",
                    HttpMethod.POST, new HttpEntity<>(dto, new HttpHeaders()), ResponseEntity.class);
            result = response.getStatusCodeValue() == 200;
        } catch (Exception e) {
            e.printStackTrace();
            result = false;
        }
        return result;
    }

    public ProductDto modifyProduct(PriceChangeDto dto) {
        ProductDto result = null;
        try {
            ResponseEntity<ProductDto> response = restTemplate.exchange(API_URL + "/api/product",
                    HttpMethod.PUT, new HttpEntity<>(dto, new HttpHeaders()), ProductDto.class);
            if (response.getBody() != null) {
                System.out.println(response.getBody().toString());
                result = response.getBody();
            }
        } catch (Exception e) {
            e.printStackTrace();
            result = null;
        }
        return result;
    }
}
